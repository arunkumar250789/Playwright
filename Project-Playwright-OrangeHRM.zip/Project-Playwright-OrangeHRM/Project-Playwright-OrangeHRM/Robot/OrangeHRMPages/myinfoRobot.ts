import { Page } from "@playwright/test";
import { BaseEyes, BaseHands } from "../BaseRobot";

export class MyInfoEyes extends BaseEyes {
  constructor(page: Page) {
    super(page);
  }

async seesMyInfoPageElements() {
    await super.seesDomVisible('div[class="oxd-input oxd-input--active"] > input[placeholder="yyyy-mm-dd"]', 1);
    await super.seesDomEnabled('div > button[type="submit"]', 0);
  }
}

export class MyInfoHands extends BaseHands {
  constructor(page: Page) {
    super(page);
  }

  async clickOnDOBIcon() {
    await super.clickOnDomElementWithIndex('div[class="oxd-input oxd-input--active"] > input[placeholder="yyyy-mm-dd"]', 1);
  }

  async typeDateOfBirth(firstName: string) {
    await super.typeTextonDom('div > input[placeholder="yyyy-mm-dd"]', dateOfBirth);
  }

  async clickOnSaveButton() {
    await super.clickOnDomElementWithIndex('div > button[type="submit"]', 0);
  }
}
