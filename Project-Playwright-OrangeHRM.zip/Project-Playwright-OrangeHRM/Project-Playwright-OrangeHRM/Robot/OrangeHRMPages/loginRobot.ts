import { Page } from "@playwright/test";
import { BaseEyes, BaseHands, BaseDependencies } from "../BaseRobot";

export class LoginRobotEyes extends BaseEyes {
  constructor(page: Page) {
    super(page);
  }
  async seesLoginPageElements() {
    await super.seesDomVisible('input[name="username"]');
    await super.seesDomVisible('input[name="password"]');
    await super.seesDomEnabled('button[type="submit"]');
    await super.seesDomVisible('img[alt="company-branding"]');
    await super.seesDomContainTextWithIndex("div > p", "Username : Admin", 0);
    await super.seesDomContainTextWithIndex(
      "div > p",
      "Password : admin123",
      1
    );
    await super.seesDomContainTextWithIndex(
      "div > p",
      "Forgot your password?",
      2
    );
    await super.seesDomContainTextWithIndex("div > p", "OrangeHRM OS 5.4", 3);
  }
}

export class LoginRobotDependencies extends BaseDependencies {
  constructor(page: Page) {
    super(page);
  }
  async visitHomePage() {
    await super.visitUrl("https://opensource-demo.orangehrmlive.com/");
  }
}

export class LoginRobotHands extends BaseHands {
  constructor(page: Page) {
    super(page);
  }

  async inputEmailId(email: string) {
    await super.typeTextonDom('input[name="username"]', email);
  }
  async inputPassword(password: string) {
    await super.typeTextonDom('input[name="password"]', password);
  }
  async clickOnLoginButton() {
    await super.clickOnDomElement('button[type="submit"]');
  }
  async clickOnHamburgerIcon() {
    await super.scrollIntoElement('aside[class="sidebar"]');
    await super.clickOnDomElement('em[id="hamburger_icon"]');
  }
}
