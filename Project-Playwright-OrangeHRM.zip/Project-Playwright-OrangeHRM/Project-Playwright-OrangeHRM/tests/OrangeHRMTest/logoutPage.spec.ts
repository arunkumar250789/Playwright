import { expect, BrowserContext, Page } from "@playwright/test";
import {
  LogoutRobotDependencies,
  LogoutRobotEyes,
  LogoutRobotHands,
} from "../../Robot/OrangeHRMPages/logoutRobot";
import { test, assert } from "../../fixturesD/myFixtures";

export default function createTests() {
  test.describe("Logout Testing", async () => {
    test("001-Logout with Valid Credentials", async ({
      browser,
      ValidUserName,
      ValidPassword,
    }) => {
      const context = await browser.newContext();
      const page = await context.newPage();
      const logoutRobotDependenciesObj = new logoutRobotDependencies(page);
      const logoutRobotEyesObj = new logoutRobotEyes(page);
      const logoutRobotHandsObj = new logoutRobotHands(page);

      await logoutRobotDependenciesObj.visitHomePage();
      await logoutRobotEyesObj.seesLogoutPageElements();
      await logoutRobotHandsObj.inputEmailId(ValidUserName);
      await logoutRobotHandsObj.inputPassword(ValidPassword);
      await logoutRobotHandsObj.clickOnLoginButton();
      await page.waitForLoadState();
      await logoutRobotEyesObj.validateDashboardUrl();
      await logoutRobotHandsObj.clickOnSignOut();
    });
  });
}