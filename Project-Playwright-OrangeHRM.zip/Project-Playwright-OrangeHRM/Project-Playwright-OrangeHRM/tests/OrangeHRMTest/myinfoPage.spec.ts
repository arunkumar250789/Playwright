import { expect, BrowserContext, Page } from "@playwright/test";
import {
  LoginRobotDependencies,
  LoginRobotEyes,
  LoginRobotHands,
} from "../../Robot/OrangeHRMPages/loginRobot";
import {
  MyInfoRobotEyes,
  MyInfoRobotHands,
} from "../../Robot/OrangeHRMPages/myinfoRobot";
import { test } from "../../fixturesD/myFixtures";

export default function createTests() {
  test.describe("My Info Page Testing", async () => {
    test("001-My Info Page and check for DOB elements", async ({
      browser,
      ValidUserName,
      ValidPassword,
      DateOfBirth,
    }) => {
      const context = await browser.newContext();
      const page = await context.newPage();
      const loginRobotDependenciesObj = new LoginRobotDependencies(page);
      const loginRobotEyesObj = new LoginRobotEyes(page);
      const loginRobotHandsObj = new LoginRobotHands(page);
      const myinfoRobotEyesObj = new MyInfoRobotEyes(page);
      const myinfoRobotHandsObj = new MyInfoRobotHands(page);

      await loginRobotDependenciesObj.visitHomePage();
      await loginRobotEyesObj.seesLoginPageElements();
      await loginRobotHandsObj.inputEmailId(ValidUserName);
      await loginRobotHandsObj.inputPassword(ValidPassword);
      await loginRobotHandsObj.clickOnLoginButton();
      await page.waitForLoadState();
      await myinfoRobotEyesObj.seesMyInfoPageElements();
      await myinfoRobotHandsObj.typeDateOfBirth(DateOfBirth);
      await page.waitForTimeout(5000);
      await pimRobotHandsObj.clickOnSaveButton();
    });
  });
}
