import { test } from "@playwright/test";
import loginPageTests from "./tests/OrangeHRMTest/loginPage.spec";
import myinfoPageTests from "./tests/OrangeHRMTest/myinfoPage.spec";
import logoutPageTests from "./tests/OrangeHRMTest/logoutPage.spec";

test.describe(loginPageTests);
test.describe(myinfoPageTests);
test.describe(logoutPageTests);
