/* eslint-disable no-unused-vars */
// 1. import the test and alias it as baseTest
// 2. Declare the type for the type myfixtureType. Can have multiple values
// 3. Create another var called fixture, using baseTest extend to the generic type
// myfixtureType

import { test as baseTest } from "@playwright/test";

type myfixtureType = {
  ValidUserName: string;
  ValidPassword: string;
  DateOfBirth: string;
};

const fixture = baseTest.extend<myfixtureType>({
  ValidPassword: "admin123",
  ValidUserName: "Admin",
  DateOfBirth: "1988-10-15",
});
// This fixture is the actual "test" from playwright test (line number 2)
export const test = fixture;
export const assert = fixture.expect;
